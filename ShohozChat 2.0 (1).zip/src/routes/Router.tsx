import { createBrowserRouter, Navigate } from 'react-router-dom';
import { AppShell } from '@/components/layout/AppShell';
import { ProtectedRoute } from './ProtectedRoute';
import { InboxPage } from '@/pages/InboxPage';
import { PeoplePage } from '@/pages/PeoplePage';
import { StoriesPage } from '@/pages/StoriesPage';
import { SettingsPage } from '@/pages/SettingsPage';
import { NotFoundPage } from '@/pages/NotFoundPage';

export const router = createBrowserRouter([
  {
    path: '/',
    element: (
      <ProtectedRoute>
        <AppShell />
      </ProtectedRoute>
    ),
    children: [
      { index: true, element: <InboxPage /> },
      { path: 'people', element: <PeoplePage /> },
      { path: 'stories', element: <StoriesPage /> },
      { path: 'settings', element: <SettingsPage /> },
      { path: '404', element: <NotFoundPage /> },
      { path: '*', element: <Navigate to="/404" replace /> },
    ],
  },
]);