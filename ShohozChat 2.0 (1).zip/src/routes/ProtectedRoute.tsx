import type { ReactNode } from 'react';

/**
 * Phase 2 replaces this body with a real auth gate:
 *   - subscribe to `onAuthStateChanged`
 *   - while loading  → <FullPageSpinner />
 *   - if no user     → <Navigate to="/auth" replace state={{ from: location }} />
 *   - if user exists → render children
 *
 * Until Firebase Authentication is configured and tested, this component is a
 * deliberate pass-through. It is NOT a security boundary on its own —
 * Firestore and Storage Security Rules are.
 */
export function ProtectedRoute({ children }: { children: ReactNode }) {
  return <>{children}</>;
}