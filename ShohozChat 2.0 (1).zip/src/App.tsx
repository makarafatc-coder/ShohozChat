import { I18nProvider } from '@/i18n/I18nProvider';

export default function App() {
  return (
    <I18nProvider>
      <div style={{ padding: 24, color: 'white', background: '#090B10', minHeight: '100vh' }}>
        <h1 style={{ fontSize: 28, fontWeight: 700 }}>Viora ✅</h1>
        <p style={{ opacity: 0.7, marginTop: 8 }}>React + Vite + TypeScript চলছে</p>
        <p style={{ opacity: 0.5, marginTop: 4, fontSize: 13 }}>
          এখন বাকি ফাইলগুলো যোগ করলে আসল UI দেখাবে।
        </p>
      </div>
    </I18nProvider>
  );
}