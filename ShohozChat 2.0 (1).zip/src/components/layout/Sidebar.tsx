import { NavLink } from 'react-router-dom';
import { Moon, Sun } from 'lucide-react';
import { NAV_ITEMS } from './nav-items';
import { Logo } from '@/components/brand/Logo';
import { IconButton } from '@/components/ui/IconButton';
import { useI18n } from '@/i18n/I18nProvider';
import { useTheme } from '@/theme/ThemeProvider';
import { cn } from '@/lib/cn';

export function Sidebar() {
  const { t } = useI18n();
  const { resolved, cycle } = useTheme();
  
  return (
    <aside className="hidden lg:flex lg:w-72 xl:w-80 shrink-0 flex-col border-r border-line bg-surface/60">
      <div className="flex items-center justify-between px-5 py-5">
        <Logo size={34} />
        <IconButton label={t('a11y.toggleTheme')} onClick={cycle}>
          {resolved === 'dark' ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
        </IconButton>
      </div>

      <nav aria-label="Primary" className="flex-1 px-3">
        <ul className="space-y-1">
          {NAV_ITEMS.map(({ to, labelKey, icon: Icon, end }) => (
            <li key={to}>
              <NavLink
                to={to}
                end={end}
                className={({ isActive }) =>
                  cn(
                    'group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors duration-150',
                    isActive
                      ? 'bg-brand/10 text-ink'
                      : 'text-muted hover:bg-surface2/70 hover:text-ink',
                  )
                }
              >
                {({ isActive }) => (
                  <>
                    <Icon
                      className={cn('h-[18px] w-[18px]', isActive ? 'text-brand' : 'text-current')}
                      aria-hidden="true"
                    />
                    <span>{t(labelKey)}</span>
                    {isActive && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-brand" />}
                  </>
                )}
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>

      <div className="border-t border-line px-5 py-4">
        <p className="text-[11px] leading-relaxed text-muted">Viora · v0.1.0 · Phase 1</p>
      </div>
    </aside>
  );
}