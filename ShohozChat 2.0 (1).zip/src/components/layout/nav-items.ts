import { Inbox, Settings, Sparkles, Users, type LucideIcon } from 'lucide-react';
import type { StringKey } from '@/i18n/strings';

export type NavItem = {
  to: string;
  labelKey: StringKey;
  icon: LucideIcon;
  end ? : boolean;
};

export const NAV_ITEMS: NavItem[] = [
  { to: '/', labelKey: 'nav.inbox', icon: Inbox, end: true },
  { to: '/people', labelKey: 'nav.people', icon: Users },
  { to: '/stories', labelKey: 'nav.stories', icon: Sparkles },
  { to: '/settings', labelKey: 'nav.settings', icon: Settings },
];