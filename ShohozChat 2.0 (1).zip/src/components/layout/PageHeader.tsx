import type { ReactNode } from 'react';

export function PageHeader({
  title,
  subtitle,
  actions,
}: {
  title: string;
  subtitle ? : string;
  actions ? : ReactNode;
}) {
  return (
    <div className="sticky top-0 z-20 border-b border-line bg-bg/85 px-5 py-4 backdrop-blur lg:px-8 lg:py-6">
      <div className="mx-auto flex max-w-3xl items-start justify-between gap-4">
        <div className="min-w-0">
          <h1 className="text-xl font-semibold tracking-tight text-ink lg:text-2xl">{title}</h1>
          {subtitle && <p className="mt-1 text-sm text-muted">{subtitle}</p>}
        </div>
        {actions && <div className="flex shrink-0 items-center gap-2">{actions}</div>}
      </div>
    </div>
  );
}