import { NavLink } from 'react-router-dom';
import { NAV_ITEMS } from './nav-items';
import { useI18n } from '@/i18n/I18nProvider';
import { cn } from '@/lib/cn';

export function BottomNav() {
  const { t } = useI18n();
  
  return (
    <nav
      aria-label="Primary"
      className="safe-bottom fixed inset-x-0 bottom-0 z-40 border-t border-line bg-surface/95 backdrop-blur lg:hidden"
    >
      <ul className="mx-auto flex max-w-lg items-stretch">
        {NAV_ITEMS.map(({ to, labelKey, icon: Icon, end }) => (
          <li key={to} className="flex-1">
            <NavLink
              to={to}
              end={end}
              className={({ isActive }) =>
                cn(
                  'flex min-h-[56px] flex-col items-center justify-center gap-1 px-1 py-2 text-[11px] font-medium transition-colors duration-150',
                  isActive ? 'text-brand' : 'text-muted hover:text-ink',
                )
              }
            >
              {({ isActive }) => (
                <>
                  <Icon
                    className="h-[21px] w-[21px]"
                    aria-hidden="true"
                    strokeWidth={isActive ? 2.4 : 2}
                  />
                  <span className="truncate">{t(labelKey)}</span>
                </>
              )}
            </NavLink>
          </li>
        ))}
      </ul>
    </nav>
  );
}