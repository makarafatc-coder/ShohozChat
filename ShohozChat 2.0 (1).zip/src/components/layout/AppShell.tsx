import { Outlet } from 'react-router-dom';
import { Moon, Sun } from 'lucide-react';
import { Sidebar } from './Sidebar';
import { BottomNav } from './BottomNav';
import { LogoMark } from '@/components/brand/Logo';
import { IconButton } from '@/components/ui/IconButton';
import { useI18n } from '@/i18n/I18nProvider';
import { useTheme } from '@/theme/ThemeProvider';

export function AppShell() {
  const { t } = useI18n();
  const { resolved, cycle } = useTheme();
  
  return (
    <div className="flex h-full min-h-0 bg-bg">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-3 focus:top-3 focus:z-50 focus:rounded-lg focus:bg-surface focus:px-3 focus:py-2 focus:text-sm focus:text-ink focus:shadow-lift"
      >
        {t('a11y.skipToContent')}
      </a>

      <Sidebar />

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="safe-top sticky top-0 z-30 flex items-center justify-between border-b border-line bg-surface/90 px-4 py-3 backdrop-blur lg:hidden">
          <div className="flex items-center gap-2.5">
            <LogoMark size={28} />
            <span className="text-[15px] font-semibold tracking-tight text-ink">Viora</span>
          </div>
          <IconButton label={t('a11y.toggleTheme')} onClick={cycle} size="sm">
            {resolved === 'dark' ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
          </IconButton>
        </header>

        <main id="main" className="min-h-0 flex-1 overflow-y-auto pb-[76px] lg:pb-0">
          <Outlet />
        </main>
      </div>

      <BottomNav />
    </div>
  );
}