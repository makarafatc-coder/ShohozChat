import { useId } from 'react';
import { cn } from '@/lib/cn';

type LogoMarkProps = {
  size ? : number;
  className ? : string;
};

export function LogoMark({ size = 36, className }: LogoMarkProps) {
  const gid = useId();
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      className={cn('shrink-0', className)}
      role="img"
      aria-label="Viora"
    >
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#7C6EFF" />
          <stop offset="55%" stopColor="#5B8DEF" />
          <stop offset="100%" stopColor="#22D3EE" />
        </linearGradient>
      </defs>
      <rect x="2" y="2" width="44" height="44" rx="14" fill={`url(#${gid})`} />
      <path
        d="M14.5 17.5A3.5 3.5 0 0 1 18 14h12a3.5 3.5 0 0 1 3.5 3.5v8A3.5 3.5 0 0 1 30 29h-6.2l-6.1 4.9c-.66.53-1.7.06-1.7-.79V17.5Z"
        fill="#fff"
        fillOpacity="0.96"
      />
      <path
        d="M19.4 19.6 24 24.6l4.6-5"
        fill="none"
        stroke={`url(#${gid})`}
        strokeWidth="2.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

type LogoProps = {
  size ? : number;
  showTagline ? : boolean;
  className ? : string;
};

export function Logo({ size = 36, showTagline = false, className }: LogoProps) {
  return (
    <div className={cn('flex items-center gap-3', className)}>
      <LogoMark size={size} />
      <div className="min-w-0 leading-tight">
        <div className="text-[17px] font-semibold tracking-tight text-ink">Viora</div>
        {showTagline && (
          <div className="truncate text-xs text-muted">Where conversations flow.</div>
        )}
      </div>
    </div>
  );
}