import type { LucideIcon } from 'lucide-react';
import type { ReactNode } from 'react';
import { cn } from '@/lib/cn';

export type EmptyStateProps = {
  icon: LucideIcon;
  title: string;
  body ? : string;
  action ? : ReactNode;
  className ? : string;
};

export function EmptyState({ icon: Icon, title, body, action, className }: EmptyStateProps) {
  return (
    <div
      className={cn(
        'flex flex-col items-center justify-center gap-3 px-6 py-14 text-center animate-fade-in',
        className,
      )}
    >
      <div className="flex h-14 w-14 items-center justify-center rounded-2xl border border-line bg-surface2/60 text-muted">
        <Icon className="h-6 w-6" aria-hidden="true" />
      </div>
      <h2 className="text-[15px] font-semibold text-ink">{title}</h2>
      {body && <p className="max-w-sm text-sm leading-relaxed text-muted">{body}</p>}
      {action && <div className="mt-1">{action}</div>}
    </div>
  );
}