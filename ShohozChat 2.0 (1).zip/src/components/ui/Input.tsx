import { forwardRef, useId, type InputHTMLAttributes, type ReactNode } from 'react';
import { cn } from '@/lib/cn';

export type InputProps = Omit < InputHTMLAttributes < HTMLInputElement > , 'size' > & {
  label ? : string;
  hint ? : string;
  error ? : string;
  leading ? : ReactNode;
  trailing ? : ReactNode;
};

export const Input = forwardRef < HTMLInputElement,
  InputProps > (function Input({ className, label, hint, error, leading, trailing, id, ...rest },
    ref,
  ) {
    const autoId = useId();
    const inputId = id ?? autoId;
    const describedBy = error ? `${inputId}-error` : hint ? `${inputId}-hint` : undefined;
    
    return (
      <div className={cn('w-full', className)}>
      {label && (
        <label htmlFor={inputId} className="mb-1.5 block text-[13px] font-medium text-ink">
          {label}
        </label>
      )}
      <div
        className={cn(
          'flex items-center gap-2 rounded-xl border bg-surface px-3',
          'transition-colors duration-150 focus-within:ring-2 focus-within:ring-brand/50',
          error ? 'border-danger' : 'border-line',
        )}
      >
        {leading && <span className="text-muted [&_svg]:h-4 [&_svg]:w-4">{leading}</span>}
        <input
          ref={ref}
          id={inputId}
          aria-invalid={error ? true : undefined}
          aria-describedby={describedBy}
          className={cn(
            'h-11 w-full bg-transparent text-sm text-ink placeholder:text-muted',
            'outline-none disabled:cursor-not-allowed disabled:opacity-60',
          )}
          {...rest}
        />
        {trailing && <span className="text-muted [&_svg]:h-4 [&_svg]:w-4">{trailing}</span>}
      </div>
      {error ? (
        <p id={`${inputId}-error`} role="alert" className="mt-1.5 text-xs text-danger">
          {error}
        </p>
      ) : hint ? (
        <p id={`${inputId}-hint`} className="mt-1.5 text-xs text-muted">
          {hint}
        </p>
      ) : null}
    </div>
    );
  });