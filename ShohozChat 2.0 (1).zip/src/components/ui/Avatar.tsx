import { useEffect, useState } from 'react';
import { cn } from '@/lib/cn';

export type PresenceStatus = 'online' | 'away' | 'offline';

export type AvatarProps = {
  src?: string | null;
  name: string;
  size?: number;
  status?: PresenceStatus;
  className?: string;
};

const STATUS_COLOR: Record<PresenceStatus, string> = {
  online: 'bg-success',
  away: 'bg-amber-400',
  offline: 'bg-muted',
};

function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return '?';
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

function hueFromName(name: string): number {
  let hash = 0;
  for (let i = 0; i < name.length; i += 1) {
    hash = (hash << 5) - hash + name.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash) % 360;
}

export function Avatar({ src, name, size = 44, status, className }: AvatarProps) {
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [src]);

  const showImage = Boolean(src) && !failed;
  const hue = hueFromName(name || '?');
  const dot = Math.max(10, Math.round(size * 0.26));

  return (
    <span
      className={cn('relative inline-block shrink-0', className)}
      style={{ width: size, height: size }}
    >
      {showImage ? (
        <img
          src={src as string}
          alt=""
          loading="lazy"
          decoding="async"
          onError={() => setFailed(true)}
          className="h-full w-full rounded-full object-cover"
        />
      ) : (
        <span
          aria-hidden="true"
          className="flex h-full w-full items-center justify-center rounded-full font-semibold text-white"
          style={{
            fontSize: Math.max(11, Math.round(size * 0.36)),
            background: `linear-gradient(140deg, hsl(${hue} 62% 52%), hsl(${(hue + 42) % 360} 66% 42%))`,
          }}
        >
          {initials(name)}
        </span>
      )}
      {status && (
        <span
          title={status}
          className={cn(
            'absolute bottom-0 right-0 rounded-full ring-2 ring-bg',
            STATUS_COLOR[status],
          )}
          style={{ width: dot, height: dot }}
        >
          <span className="sr-only">{status}</span>
        </span>
      )}
      <span className="sr-only">{name}</span>
    </span>
  );
}