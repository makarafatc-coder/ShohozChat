import { forwardRef, type ButtonHTMLAttributes } from 'react';
import { cn } from '@/lib/cn';

export type IconButtonProps = ButtonHTMLAttributes < HTMLButtonElement > & {
  label: string;
  size ? : 'sm' | 'md';
};

export const IconButton = forwardRef < HTMLButtonElement,
  IconButtonProps > (function IconButton({ label, className, size = 'md', children, ...rest },
    ref,
  ) {
    return (
      <button
      ref={ref}
      type="button"
      aria-label={label}
      title={label}
      className={cn(
        'inline-flex items-center justify-center rounded-xl text-muted',
        'transition-colors duration-150 hover:bg-surface2/70 hover:text-ink',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand/70 focus-visible:ring-offset-2 focus-visible:ring-offset-bg',
        'disabled:cursor-not-allowed disabled:opacity-40 active:scale-[0.96]',
        size === 'sm' ? 'h-8 w-8' : 'h-10 w-10',
        className,
      )}
      {...rest}
    >
      {children}
    </button>
    );
  });