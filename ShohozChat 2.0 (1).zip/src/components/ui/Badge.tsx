import type { ReactNode } from 'react';
import { cn } from '@/lib/cn';

type Tone = 'brand' | 'neutral' | 'danger' | 'success';

const TONES: Record < Tone, string > = {
  brand: 'bg-brand text-brand-fg',
  neutral: 'bg-surface2 text-muted',
  danger: 'bg-danger text-white',
  success: 'bg-success text-white',
};

export function Badge({
  children,
  tone = 'neutral',
  className,
}: {
  children: ReactNode;
  tone ? : Tone;
  className ? : string;
}) {
  return (
    <span
      className={cn(
        'inline-flex min-w-[20px] items-center justify-center rounded-full px-1.5 text-[11px] font-semibold leading-5',
        TONES[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}