import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import { bn, en, type StringKey } from './strings';
import { readStore, writeStore } from '@/lib/storage';

export type Language = 'en' | 'bn';

const STORAGE_KEY = 'viora.lang';
const DICTIONARIES: Record < Language, Record < StringKey, string >> = { en, bn };

type I18nContextValue = {
  language: Language;
  setLanguage: (next: Language) => void;
  t: (key: StringKey, vars ? : Record < string, string | number > ) => string;
};

const I18nContext = createContext < I18nContextValue | null > (null);

function interpolate(template: string, vars ? : Record < string, string | number > ) {
  if (!vars) return template;
  return template.replace(/\{(\w+)\}/g, (match, name: string) =>
    Object.prototype.hasOwnProperty.call(vars, name) ? String(vars[name]) : match,
  );
}

export function I18nProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState < Language > (() =>
    readStore < Language > (STORAGE_KEY, 'en'),
  );
  
  useEffect(() => {
    document.documentElement.lang = language;
    writeStore(STORAGE_KEY, language);
  }, [language]);
  
  const setLanguage = useCallback((next: Language) => setLanguageState(next), []);
  
  const t = useCallback < I18nContextValue['t'] > (
    (key, vars) => {
      const dict = DICTIONARIES[language] ?? en;
      const template = dict[key] ?? en[key] ?? key;
      return interpolate(template, vars);
    },
    [language],
  );
  
  const value = useMemo(() => ({ language, setLanguage, t }), [language, setLanguage, t]);
  
  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n(): I18nContextValue {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error('useI18n must be used inside <I18nProvider>');
  return ctx;
}