export const en = {
  'app.name': 'Viora',
  'app.tagline': 'Where conversations flow.',

  'nav.inbox': 'Inbox',
  'nav.people': 'People',
  'nav.stories': 'Stories',
  'nav.settings': 'Settings',

  'common.search': 'Search',
  'common.cancel': 'Cancel',
  'common.close': 'Close',
  'common.retry': 'Try again',
  'common.loading': 'Loading…',
  'common.comingSoon': 'Coming soon',
  'common.phaseNote': 'Arrives in {phase}.',

  'inbox.title': 'Inbox',
  'inbox.subtitle': 'Your conversations, all in one place.',
  'inbox.searchPlaceholder': 'Search people and conversations',
  'inbox.filter.all': 'All',
  'inbox.filter.unread': 'Unread',
  'inbox.filter.groups': 'Groups',
  'inbox.filter.archived': 'Archived',
  'inbox.empty.title': 'No conversations yet',
  'inbox.empty.body':
    'Once you start chatting, your conversations will show up here — sorted by the latest activity.',

  'people.title': 'People',
  'people.subtitle': 'Find friends and discover new connections.',
  'people.empty.title': 'Discovery opens up soon',
  'people.empty.body':
    'User search, friend requests and profile viewing are being wired up.',

  'stories.title': 'Stories',
  'stories.subtitle': 'Share a moment. It disappears in 24 hours.',
  'stories.empty.title': 'No stories right now',
  'stories.empty.body': 'Stories from people you follow will appear here.',

  'settings.title': 'Settings',
  'settings.subtitle': 'Control how Viora looks, sounds and behaves.',
  'settings.appearance': 'Appearance',
  'settings.theme': 'Theme',
  'settings.theme.light': 'Light',
  'settings.theme.dark': 'Dark',
  'settings.theme.system': 'System',
  'settings.language': 'Language',
  'settings.language.en': 'English',
  'settings.language.bn': 'বাংলা',
  'settings.privacy': 'Privacy',
  'settings.privacy.note':
    'Read receipts, last seen and online status controls arrive in Phase 5.',
  'settings.notifications': 'Notifications',
  'settings.notifications.note': 'Push notifications are enabled in Phase 5.',
  'settings.account': 'Account',
  'settings.account.note':
    'Sign-in, profile editing and account deletion arrive in Phase 2.',
  'settings.about': 'About',
  'settings.version': 'Version',
  'settings.build': 'Build',

  'notFound.title': 'Page not found',
  'notFound.body': 'The page you were looking for does not exist.',
  'notFound.action': 'Back to inbox',

  'a11y.skipToContent': 'Skip to main content',
  'a11y.toggleTheme': 'Toggle theme',
} as const;

export type StringKey = keyof typeof en;

export const bn: Record<StringKey, string> = {
  'app.name': 'ভিওরা',
  'app.tagline': 'যেখানে কথোপকথন প্রবাহিত হয়।',

  'nav.inbox': 'ইনবক্স',
  'nav.people': 'মানুষ',
  'nav.stories': 'স্টোরি',
  'nav.settings': 'সেটিংস',

  'common.search': 'খুঁজুন',
  'common.cancel': 'বাতিল',
  'common.close': 'বন্ধ',
  'common.retry': 'আবার চেষ্টা করুন',
  'common.loading': 'লোড হচ্ছে…',
  'common.comingSoon': 'শীঘ্রই আসছে',
  'common.phaseNote': '{phase}-এ আসছে।',

  'inbox.title': 'ইনবক্স',
  'inbox.subtitle': 'আপনার সব কথোপকথন এক জায়গায়।',
  'inbox.searchPlaceholder': 'মানুষ ও কথোপকথন খুঁজুন',
  'inbox.filter.all': 'সব',
  'inbox.filter.unread': 'অপঠিত',
  'inbox.filter.groups': 'গ্রুপ',
  'inbox.filter.archived': 'আর্কাইভ',
  'inbox.empty.title': 'এখনো কোনো কথোপকথন নেই',
  'inbox.empty.body':
    'চ্যাট শুরু করলে আপনার কথোপকথনগুলো এখানে দেখা যাবে — সর্বশেষ কার্যকলাপ অনুযায়ী সাজানো।',

  'people.title': 'মানুষ',
  'people.subtitle': 'বন্ধু খুঁজুন এবং নতুন সংযোগ তৈরি করুন।',
  'people.empty.title': 'অনুসন্ধান শীঘ্রই চালু হবে',
  'people.empty.body':
    'ব্যবহারকারী অনুসন্ধান, বন্ধুর অনুরোধ ও প্রোফাইল দেখা যুক্ত করা হচ্ছে।',

  'stories.title': 'স্টোরি',
  'stories.subtitle': 'একটি মুহূর্ত শেয়ার করুন। ২৪ ঘণ্টায় মুছে যাবে।',
  'stories.empty.title': 'এখন কোনো স্টোরি নেই',
  'stories.empty.body':
    'আপনি যাদের অনুসরণ করেন তাদের স্টোরি এখানে দেখা যাবে।',

  'settings.title': 'সেটিংস',
  'settings.subtitle':
    'ভিওরা কীভাবে দেখাবে, শোনাবে ও আচরণ করবে তা নিয়ন্ত্রণ করুন।',
  'settings.appearance': 'চেহারা',
  'settings.theme': 'থিম',
  'settings.theme.light': 'হালকা',
  'settings.theme.dark': 'গাঢ়',
  'settings.theme.system': 'সিস্টেম',
  'settings.language': 'ভাষা',
  'settings.language.en': 'English',
  'settings.language.bn': 'বাংলা',
  'settings.privacy': 'গোপনীয়তা',
  'settings.privacy.note':
    'রিড রিসিট, সর্বশেষ দেখা ও অনলাইন স্ট্যাটাস নিয়ন্ত্রণ ফেজ ৫-এ আসছে।',
  'settings.notifications': 'বিজ্ঞপ্তি',
  'settings.notifications.note': 'পুশ বিজ্ঞপ্তি ফেজ ৫-এ চালু হবে।',
  'settings.account': 'অ্যাকাউন্ট',
  'settings.account.note':
    'সাইন-ইন, প্রোফাইল সম্পাদনা ও অ্যাকাউন্ট মুছে ফেলা ফেজ ২-এ আসছে।',
  'settings.about': 'সম্পর্কে',
  'settings.version': 'সংস্করণ',
  'settings.build': 'বিল্ড',

  'notFound.title': 'পৃষ্ঠা পাওয়া যায়নি',
  'notFound.body': 'আপনি যে পৃষ্ঠাটি খুঁজছেন তা বিদ্যমান নেই।',
  'notFound.action': 'ইনবক্সে ফিরে যান',

  'a11y.skipToContent': 'মূল কনটেন্টে যান',
  'a11y.toggleTheme': 'থিম পরিবর্তন করুন',
};