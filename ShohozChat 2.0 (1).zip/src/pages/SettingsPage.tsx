import type { ReactNode } from 'react';
import { Check, Info, Languages, Monitor, Moon, Sun } from 'lucide-react';
import { PageHeader } from '@/components/layout/PageHeader';
import { useI18n, type Language } from '@/i18n/I18nProvider';
import { useTheme, type ThemePreference } from '@/theme/ThemeProvider';
import { cn } from '@/lib/cn';
import type { StringKey } from '@/i18n/strings';

const THEME_OPTIONS: { id: ThemePreference;labelKey: StringKey;icon: typeof Sun } [] = [
  { id: 'light', labelKey: 'settings.theme.light', icon: Sun },
  { id: 'dark', labelKey: 'settings.theme.dark', icon: Moon },
  { id: 'system', labelKey: 'settings.theme.system', icon: Monitor },
];

const LANGUAGE_OPTIONS: { id: Language;labelKey: StringKey } [] = [
  { id: 'en', labelKey: 'settings.language.en' },
  { id: 'bn', labelKey: 'settings.language.bn' },
];

function Section({
  title,
  icon: Icon,
  children,
}: {
  title: string;
  icon: typeof Sun;
  children: ReactNode;
}) {
  return (
    <section className="surface-card overflow-hidden">
      <header className="flex items-center gap-2.5 border-b border-line px-4 py-3">
        <Icon className="h-4 w-4 text-brand" aria-hidden="true" />
        <h2 className="text-[13px] font-semibold uppercase tracking-wide text-muted">
          {title}
        </h2>
      </header>
      <div className="p-4">{children}</div>
    </section>
  );
}

function OptionRow({
  selected,
  onSelect,
  label,
  children,
}: {
  selected: boolean;
  onSelect: () => void;
  label: string;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      role="radio"
      aria-checked={selected}
      onClick={onSelect}
      className={cn(
        'flex w-full items-center gap-3 rounded-xl border px-3.5 py-3 text-left text-sm transition-colors duration-150',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand/70',
        selected
          ? 'border-brand/60 bg-brand/10 text-ink'
          : 'border-line bg-surface text-muted hover:text-ink hover:bg-surface2/60',
      )}
    >
      {children}
      <span className="flex-1 font-medium">{label}</span>
      {selected && <Check className="h-4 w-4 text-brand" aria-hidden="true" />}
    </button>
  );
}

export function SettingsPage() {
  const { t, language, setLanguage } = useI18n();
  const { preference, setPreference } = useTheme();
  
  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader title={t('settings.title')} subtitle={t('settings.subtitle')} />

      <div className="space-y-4 px-5 py-5 lg:px-8">
        <Section title={t('settings.appearance')} icon={Sun}>
          <p className="mb-3 text-[13px] font-medium text-ink">{t('settings.theme')}</p>
          <div
            role="radiogroup"
            aria-label={t('settings.theme')}
            className="grid gap-2 sm:grid-cols-3"
          >
            {THEME_OPTIONS.map(({ id, labelKey, icon: Icon }) => (
              <OptionRow
                key={id}
                selected={preference === id}
                onSelect={() => setPreference(id)}
                label={t(labelKey)}
              >
                <Icon className="h-4 w-4" aria-hidden="true" />
              </OptionRow>
            ))}
          </div>
        </Section>

        <Section title={t('settings.language')} icon={Languages}>
          <div
            role="radiogroup"
            aria-label={t('settings.language')}
            className="grid gap-2 sm:grid-cols-2"
          >
            {LANGUAGE_OPTIONS.map(({ id, labelKey }) => (
              <OptionRow
                key={id}
                selected={language === id}
                onSelect={() => setLanguage(id)}
                label={t(labelKey)}
              >
                <Languages className="h-4 w-4" aria-hidden="true" />
              </OptionRow>
            ))}
          </div>
        </Section>

        <Section title={t('settings.privacy')} icon={Info}>
          <p className="text-sm leading-relaxed text-muted">{t('settings.privacy.note')}</p>
        </Section>

        <Section title={t('settings.notifications')} icon={Info}>
          <p className="text-sm leading-relaxed text-muted">
            {t('settings.notifications.note')}
          </p>
        </Section>

        <Section title={t('settings.account')} icon={Info}>
          <p className="text-sm leading-relaxed text-muted">{t('settings.account.note')}</p>
        </Section>

        <Section title={t('settings.about')} icon={Info}>
          <dl className="grid gap-2 text-sm">
            <div className="flex items-center justify-between">
              <dt className="text-muted">{t('settings.version')}</dt>
              <dd className="font-medium text-ink">0.1.0</dd>
            </div>
            <div className="flex items-center justify-between">
              <dt className="text-muted">{t('settings.build')}</dt>
              <dd className="font-medium text-ink">Phase 1</dd>
            </div>
          </dl>
        </Section>
      </div>
    </div>
  );
}