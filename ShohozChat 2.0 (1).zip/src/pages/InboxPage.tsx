import { useMemo, useState } from 'react';
import { MessageSquareDashed, Search } from 'lucide-react';
import { PageHeader } from '@/components/layout/PageHeader';
import { EmptyState } from '@/components/ui/EmptyState';
import { Input } from '@/components/ui/Input';
import { useI18n } from '@/i18n/I18nProvider';
import type { StringKey } from '@/i18n/strings';
import { cn } from '@/lib/cn';

type Filter = 'all' | 'unread' | 'groups' | 'archived';

const FILTERS: { id: Filter;labelKey: StringKey } [] = [
  { id: 'all', labelKey: 'inbox.filter.all' },
  { id: 'unread', labelKey: 'inbox.filter.unread' },
  { id: 'groups', labelKey: 'inbox.filter.groups' },
  { id: 'archived', labelKey: 'inbox.filter.archived' },
];

export function InboxPage() {
  const { t } = useI18n();
  const [filter, setFilter] = useState < Filter > ('all');
  const [query, setQuery] = useState('');
  
  // Phase 3 replaces this with a paginated Firestore subscription.
  const conversations = useMemo < never[] > (() => [], []);
  
  const isEmpty = conversations.length === 0;
  
  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader title={t('inbox.title')} subtitle={t('inbox.subtitle')} />

      <div className="px-5 pt-4 lg:px-8">
        <Input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={t('inbox.searchPlaceholder')}
          aria-label={t('common.search')}
          leading={<Search />}
        />

        <div
          role="tablist"
          aria-label={t('inbox.title')}
          className="mt-4 flex gap-2 overflow-x-auto pb-1"
        >
          {FILTERS.map(({ id, labelKey }) => {
            const active = filter === id;
            return (
              <button
                key={id}
                role="tab"
                type="button"
                aria-selected={active}
                onClick={() => setFilter(id)}
                className={cn(
                  'shrink-0 rounded-full px-3.5 py-1.5 text-[13px] font-medium transition-colors duration-150',
                  'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand/70',
                  active
                    ? 'bg-brand text-brand-fg'
                    : 'border border-line bg-surface text-muted hover:text-ink',
                )}
              >
                {t(labelKey)}
              </button>
            );
          })}
        </div>
      </div>

      <div className="px-5 py-4 lg:px-8">
        {isEmpty && (
          <div className="surface-card mt-2">
            <EmptyState
              icon={MessageSquareDashed}
              title={t('inbox.empty.title')}
              body={t('inbox.empty.body')}
            />
            <p className="pb-5 text-center text-xs text-muted">
              {t('common.phaseNote', { phase: 'Phase 3' })}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}