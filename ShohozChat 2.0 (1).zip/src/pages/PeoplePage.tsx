import { UserRoundSearch } from 'lucide-react';
import { PageHeader } from '@/components/layout/PageHeader';
import { EmptyState } from '@/components/ui/EmptyState';
import { useI18n } from '@/i18n/I18nProvider';

export function PeoplePage() {
  const { t } = useI18n();
  
  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader title={t('people.title')} subtitle={t('people.subtitle')} />
      <div className="px-5 py-4 lg:px-8">
        <div className="surface-card mt-2">
          <EmptyState
            icon={UserRoundSearch}
            title={t('people.empty.title')}
            body={t('people.empty.body')}
          />
          <p className="pb-5 text-center text-xs text-muted">
            {t('common.phaseNote', { phase: 'Phase 5' })}
          </p>
        </div>
      </div>
    </div>
  );
}