import { Sparkles } from 'lucide-react';
import { PageHeader } from '@/components/layout/PageHeader';
import { EmptyState } from '@/components/ui/EmptyState';
import { useI18n } from '@/i18n/I18nProvider';

export function StoriesPage() {
  const { t } = useI18n();
  
  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader title={t('stories.title')} subtitle={t('stories.subtitle')} />
      <div className="px-5 py-4 lg:px-8">
        <div className="surface-card mt-2">
          <EmptyState
            icon={Sparkles}
            title={t('stories.empty.title')}
            body={t('stories.empty.body')}
          />
          <p className="pb-5 text-center text-xs text-muted">
            {t('common.phaseNote', { phase: 'Phase 5' })}
          </p>
        </div>
      </div>
    </div>
  );
}