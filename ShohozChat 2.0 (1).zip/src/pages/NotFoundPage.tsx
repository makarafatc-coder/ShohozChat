import { Link } from 'react-router-dom';
import { Compass } from 'lucide-react';
import { EmptyState } from '@/components/ui/EmptyState';
import { useI18n } from '@/i18n/I18nProvider';

export function NotFoundPage() {
  const { t } = useI18n();
  
  return (
    <div className="mx-auto flex min-h-[60vh] max-w-lg items-center justify-center px-5">
      <EmptyState
        icon={Compass}
        title={t('notFound.title')}
        body={t('notFound.body')}
        action={
          <Link
            to="/"
            className="inline-flex h-10 items-center rounded-xl bg-brand px-4 text-sm font-medium text-brand-fg transition-[filter] hover:brightness-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand/70 focus-visible:ring-offset-2 focus-visible:ring-offset-bg"
          >
            {t('notFound.action')}
          </Link>
        }
      />
    </div>
  );
}